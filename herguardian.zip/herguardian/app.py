from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_socketio import SocketIO
import os
from dotenv import load_dotenv
import random
from datetime import datetime
import uuid
from werkzeug.utils import secure_filename

# Configuration
load_dotenv()
app = Flask(__name__, template_folder='templates')
app.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key')
app.config['UPLOAD_FOLDER'] = 'static/images/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}
socketio = SocketIO(app)

# Mock Database
users_db = {}
rides_db = {}
drivers_db = {
    "driver1": {
        "id": "driver1",
        "name": "Sarah K.",
        "avatar": "/static/images/driver-avatar.jpg",
        "rating": 4.9,
        "car": {
            "make": "Toyota",
            "model": "Corolla",
            "color": "Pink",
            "license": "HERG123"
        }
    }
}

# Helper Functions
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def generate_otp():
    return str(random.randint(100000, 999999))

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        if email in users_db:
            return "Email already exists", 400
            
        # Generate OTP
        otp = generate_otp()
        session['registration_otp'] = otp
        session['registration_data'] = request.form.to_dict()
        
        print(f"DEMO OTP: {otp}")  # In production, send via SMS/email
        return redirect(url_for('verify_otp'))
    
    return render_template('register.html')

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    if 'registration_data' not in session:
        return redirect(url_for('register'))
    
    if request.method == 'POST':
        user_otp = request.form.get('otp')
        if user_otp == session.get('registration_otp'):
            # Create user account
            user_data = session['registration_data']
            user_id = str(uuid.uuid4())
            
            users_db[user_id] = {
                "id": user_id,
                "email": user_data['email'],
                "password": user_data['password'],
                "name": user_data['name'],
                "phone": user_data['phone'],
                "rating": 5.0,  # Default rating
                "avatar": "/static/images/default-avatar.png"
            }
            
            session['user'] = users_db[user_id]
            return redirect(url_for('dashboard'))
    
    return render_template('verify_otp.html', demo_otp=session.get('registration_otp'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Find user by email
        user = next((u for u in users_db.values() if u['email'] == email), None)
        
        if user and user['password'] == password:
            session['user'] = user
            return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', user=session['user'])

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        user = session['user']
        
        # Handle file upload
        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and allowed_file(file.filename):
                filename = secure_filename(f"{user['id']}.{file.filename.rsplit('.', 1)[1].lower()}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                user['avatar'] = f"/static/images/uploads/{filename}"
        
        # Update other fields
        user['name'] = request.form.get('name', user['name'])
        user['phone'] = request.form.get('phone', user['phone'])
        user['emergency_contact'] = request.form.get('emergency_contact', user.get('emergency_contact'))
        
        session['user'] = user
        return redirect(url_for('profile'))
    
    return render_template('profile.html', user=session['user'])

@app.route('/promotions')
def promotions():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('promotions.html')

@app.route('/request-ride', methods=['POST'])
def request_ride():
    if 'user' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    data = request.json
    ride_id = f"ride_{random.randint(1000, 9999)}"
    
    # Calculate fare (simplified)
    distance = data.get('distance', 5)  # km
    duration = data.get('duration', 15)  # minutes
    fare = 50 + (distance * 8) + (duration * 1)
    
    # Create ride
    rides_db[ride_id] = {
        "id": ride_id,
        "user_id": session['user']['id'],
        "pickup": data.get('pickup'),
        "destination": data.get('destination'),
        "fare": fare,
        "status": "driver_assigned",
        "driver": random.choice(list(drivers_db.values())),
        "created_at": datetime.now().isoformat()
    }
    
    # Start AI monitoring
    socketio.start_background_task(monitor_ride, ride_id)
    
    return jsonify({
        "success": True,
        "ride_id": ride_id,
        "driver": rides_db[ride_id]['driver'],
        "fare": fare
    })

def monitor_ride(ride_id):
    """Simulate Gugu AI monitoring during ride"""
    import time
    time.sleep(10)  # Wait 10 seconds after ride starts
    
    # First check-in
    socketio.emit('gugu_message', {
        'ride_id': ride_id,
        'message': "Hi there! I'm Gugu, your safety AI. How are you feeling?",
        'options': ["I'm safe", "I need help"]
    }, room=ride_id)
    
    # Periodic check-ins
    while ride_id in rides_db and rides_db[ride_id]['status'] != 'completed':
        time.sleep(60)  # Check every minute
        socketio.emit('gugu_message', {
            'ride_id': ride_id,
            'message': "Just checking in - everything still okay?",
            'options': ["All good", "Not feeling safe"]
        }, room=ride_id)

@app.route('/emergency/<ride_id>')
def emergency(ride_id):
    if ride_id not in rides_db:
        return "Ride not found", 404
    
    # Notify emergency contacts
    user_id = rides_db[ride_id]['user_id']
    user = users_db.get(user_id)
    
    if user and 'emergency_contact' in user:
        print(f"ALERT: Notifying emergency contact {user['emergency_contact']}")
    
    socketio.emit('emergency_alert', {
        'ride_id': ride_id,
        'message': "Emergency assistance requested!",
        'location': rides_db[ride_id].get('current_location')
    }, room=ride_id)
    
    return "Emergency alert sent"

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    socketio.run(app, debug=True)
    
@app.route('/resend-otp')
def resend_otp():
    if 'registration_data' not in session:
        return redirect(url_for('register'))
    
    # Generate new OTP
    new_otp = generate_otp()
    session['registration_otp'] = new_otp
    
    print(f"NEW DEMO OTP: {new_otp}")
    return jsonify({
        "status": "success",
        "demo_otp": new_otp
    })